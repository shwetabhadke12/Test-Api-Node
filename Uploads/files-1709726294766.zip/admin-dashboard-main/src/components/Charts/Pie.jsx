import React from 'react'

const Pie = () => {
  return (
    <div>Pie</div>
  )
}

export default Pie