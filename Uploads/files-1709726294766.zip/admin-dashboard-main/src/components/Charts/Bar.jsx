import React from 'react'

const Bar = () => {
  return (
    <div>Bar</div>
  )
}

export default Bar