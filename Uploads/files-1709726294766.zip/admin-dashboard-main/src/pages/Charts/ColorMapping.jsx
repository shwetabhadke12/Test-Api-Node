import React from 'react'

const ColorMapping = () => {
  return (
    <div>ColorMapping</div>
  )
}

export default ColorMapping