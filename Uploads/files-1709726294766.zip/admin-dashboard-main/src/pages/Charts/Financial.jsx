import React from 'react'

const Financial = () => {
  return (
    <div>Financial</div>
  )
}

export default Financial