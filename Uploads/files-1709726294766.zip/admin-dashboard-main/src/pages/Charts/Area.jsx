import React from 'react'

const Area = () => {
  return (
    <div>Area</div>
  )
}

export default Area