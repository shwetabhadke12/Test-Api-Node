import React from 'react'

const Line = () => {
  return (
    <div>Line</div>
  )
}

export default Line