//Higher Order Functions ////////////////////////////////////////////////////////////

// forEach()
// map()
// reduce()
// filter()

//que 1)  find duplicates in this array
// const companies=[
//     {name:"Google", category:"product based", sallery_provide:30000},
//     {name:"Infosys", category:"product based", sallery_provide:50000},
//     {name:"Hexaware", category:"product based", sallery_provide:40000},
//     {name:"L&T", category:"product based", sallery_provide:35000},
//     {name:"TCS", category:"product based", sallery_provide:30000},
//     {name:"Google", category:"product based", sallery_provide:30000},
//     {name:"L&T", category:"product based", sallery_provide:35000},
// ]
// function findUnique(array) {
//     const seen = {};
//     const uniqueCompanies = [];

//     array.forEach((item) => {
//         const name = item.name.toLowerCase();

//         if (!seen[name]) {
//             uniqueCompanies.push(item);
//             seen[name] = true;
//         }
//     });
//     return uniqueCompanies
// }

// // Find unique companies in the 'companies' array
// const uniqueCompanies = findUnique(companies);
// console.log("Unique companies:", uniqueCompanies)




// const va =[1,2,3,4,5,6,7,8,9]

// const filt = va.map(x=>x<6)
// console.log(filt, "map")

// const map = va.filter(x=>x<6)
// console.log(map, "map")


const data = [
    {
      name: "Anirudh",
    },
    {
      name: "Anirudh",
    },
    {
      name: "Abhijeet",
    },
    {
      name: "Abhijeet",
    },
    {
      name: "Abhijeet",
    },
    {
      name: "rahul",
    },
    {
      name: "rahul",
    },
    {
      name: "rahul",
    },
    {
      name: "rahul",
    },
    {
      name: "rahul",
    },
    {
      name: "rahul",
    },
    {
      name: "rahul",
    },
    {
      name: "rahul",
    },
    {
      name: "rahul",
    },
    {
      name: "rahul",
    },
    {
      name: "rahul",
    },
    {
      name: "rahul",
    },
  ];
  let arr = {};
    data.forEach((item) => {
      if (Object.keys(arr).includes(item.name)) {
        arr[item.name] += 1;
      } else {
        arr[item.name] = 1;
      }
    });
    console.log(arr)