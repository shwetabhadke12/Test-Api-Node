// const { rejects } = require("assert");
// const { errorMonitor } = require("events");
// const { resolve } = require("path");
// const { promises } = require("stream");

//fill method
// let myArr = [1, 3, 4, 5, 9, 54, 6];
// console.log(myArr);

// splice method

//splice :used for delete specific element and add element in array
// let arr = ["item1", "item2", "item3", "item4"];
// let result = arr.splice(1, 2, "abc", "dcd");

// console.log(result);
// console.log(arr);

// iterable:on which we can perform loop
//array like object:which have lenghth property

//default parameter
// function defaultPM(a, b) {
//   if (typeof b === "undefined") {
//     b = 1;
//   }
//   return a + b;
// }
// let ans = defaultPM(4);
// console.log(ans);

// function defaultPM1(a, b = 2) {
//   return a + b;
// }
// let ans1 = defaultPM1(4);
// console.log(ans1);

//rest parameter

// function rest(...numbers) {
//   let total = 0;
//   for (let add of numbers) {
//     total = total + add;
//   }
//   return total;
// }
// let res = rest(2, 3, 5);
// console.log(res);



// function rest1(a, b, ...c) {
//   console.log(`a is ${a}`);
//   console.log(`b is ${b}`);
//   console.log(`c is ${c}`);
// }
// let out = rest1(2, 4, 5, 1, 7);
// console.log(out);

//params destructuring

//without destructuring

// let person = {
//   name: "ankit",
//   city: "ngp",
//   age: 23,
// };

// function printDetails(obj) {
//   console.log(obj.name);
//   console.log(obj.city);
//   console.log(obj.age);
// }
// // printDetails(person);

// //with destructuring
// function printDetail({ name, city, age }) {
//   console.log(name);
//   console.log(city);
//   console.log(age);
// }
// printDetails(person);

//function returning function

// function a() {
//   function b() {
//     return "hi all";
//   }
//   return b;
// }
// let ret = a();
// console.log(ret());

// callback function

// function call(name) {
//   console.log("inside lower");
//   console.log(`${name}`);
// }
// function higher(callback) {
//   console.log("inside higher");
//   callback("ankit");
// }

// higher(call);

//object
// let key = "email";
// let persons = { name: "ankit", age: 22, "fav thing": ["cricket", "gaming"] };
// persons[key] = "ab@gmail.com";
// console.log(persons);
// console.log(persons["fav thing"]); //return array

// // object iterable
// // by for in
// for (key in persons) {
//   console.log(`${key} : ${persons[key]}`);
// }

// //by Object.keys()
// console.log(Array.isArray(Object.keys(persons)));

// for (key of Object.keys(persons)) {
//   console.log(persons[key]);
// }

// computed property

// let key1 = "objkey1";
// let key2 = "objkey2";

// let value1 = "objvalue1";
// let value2 = "objvalue2";

// // 1st method
// // let obj = {
// //   [key1]: value1,
// //   [key2]: value2,
// // };
// // console.log(obj);

// // 2nd method
// let obj = {};
// obj[key1] = value1;
// obj[key2] = value2;

// // console.log(obj);

// let newObj = { ...obj };
// console.log(newObj);

// //object destructuring

// let obj2 = {
//   name: "ankit",
//   age: 22,
//   fav: "gaming",
//   edu: "BE",
// };

// const { name, age, ...restobj } = obj2;

// console.log(name);
// console.log(restobj);

//object inside array
// let sam = [
//   { userId: 1, name: "ab", gender: "male" },
//   { userId: 2, name: "aw", gender: "female" },
//   { userId: 3, name: "dk", gender: "male" },
// ];

// for (us of sam) {
//   console.log(us.name);
// }

//nested destructuring

//promises

// const obj1 = new Promise((resolve, reject) => {
//   setImmediate(() => {
//     let rollNum = [1, 2, 3, 4, 5];
//     resolve(rollNum);
//   }, 2000);
// });

// let getData = (indexData) => {
//   return new Promise((resolve, reject) => {
//     setTimeout(
//       (indexData) => {
//         let data = {
//           name: "ankit",
//           age: "23",
//         };
//         resolve(
//           `my roll num is ${indexData} and my name is ${data.name} and age is ${data.age}`
//         );
//       },
//       2000,
//       indexData
//     );
//   });
// };

// obj1
//   .then((rollNum) => {
//     console.log(rollNum);
//     return getData(rollNum[1]);
//   })
//   .then((anything) => {
//     console.log(anything);
//   })
//   .catch((err) => {
//     console.log(err);
//   });

// //promise all
// //fullfilled all promises ,if any one rejected it will return catch block
// let data = Promise.all([
//   new Promise((resolve, reject) => {
//     setTimeout(() => {
//       resolve("2 second");
//     }, 2000);
//   }),

//   new Promise((resolve, reject) => {
//     setTimeout(() => {
//       resolve("4 sec");
//     }, 4000);
//   }),
//   new Promise((resolve, reject) => {
//     setTimeout(() => {
//       resolve("1");
//     }, 1000);
//   }),
// ]);

// data
//   .then((item) => {
//     console.log("inside then", item);
//   })
//   .catch((error) => {
//     console.log("inside catch", error);
//   });

// // promise.allSettled
// // return fulfilled and rejected promise
// let data1 = Promise.race([
//   new Promise((resolve, reject) => {
//     setTimeout(() => {
//       resolve("2 sec");
//     }, 2000);
//   }),

//   new Promise((resolve, reject) => {
//     setTimeout(() => {
//       resolve("3 sec");
//     }, 3000);
//   }),
//   new Promise((resolve, reject) => {
//     setTimeout(() => {
//       resolve("2 sec");
//     }, 3000);
//   }),
// ]);

// data1
//   .then((item) => {
//     console.log("true", item);
//   })
//   .catch((error) => {
//     console.log(error);
//   });

// promise.race-return only first fulfilled promise

// loop

// for (let i = 0; i < 18; i += 10) {
//   console.log(i);
// }

// let str1 = "ankit";
// for (let i = 1; i < str1.length; i += 4) {
//   console.log(str1[i]);
// }

// sum of nth number
// let sum = 0;
// let n = 4;
// // let n = prompt("enter the number is ");
// // n = Number.parseInt(n);
// for (let i = 0; i < n; i++) {
//   sum = sum + (i + 1);
// }

// console.log("sum of first " + n + " number is " + sum);

// factorial number
// let sum = 1;
// let n = 5;
// for (let i = 1; i < n; i++) {
//   sum = sum * (i + 1);
// }

// console.log("fact of  " + n + " number is " + sum);

// count number of occcurence of string

// let str = "helloworld";

// let map = {};

// str.split("").forEach((e) => {
//   // console.log(e);

//   map[e] = map[e] ? map[e] + 1 : 1;
// });

// console.log(map);

// find
// let str = "helloworld";

// let map = {};

// str.split("").forEach((e) => {
//   // console.log(e);

//   map[e] = map[e] ? map[e] + 1 : 1;
// });

// let max = 1;
// char = str[0];
// for (let big in map) {
//   if (map[big] > max) {
//     max = map[big];
//     char = big;
//   }
// }

// console.log(char);
// // console.log(map);

// // find unique value
// // 1st method
// let unique = [1, 3, 4, 4, 5, 5, 8, 9, 3];
// console.log([...new Set(unique)]);

// // 2nd
// let find = unique.filter((e, pos) => {
//   return unique.indexOf(e) == pos;
// });
// console.log(find);

// //febonqanci series
// var a = 0;
// var b = 1;

// for (var i = 0; i <= 7; i++) {
//   var temp = a + b; //0 +1=1

//   a = b; //1
//   b = temp;
//   console.log(temp);
// }

// // palindrome

// let value = 121;

// let reverse = value.toString().split("").reverse().join("");
// let preValue = value.toString();

// if (reverse === preValue) {
//   console.log("palindrome");
// } else {
//   console.log(" not palindrome");
// }

// reverse string
// let value11 = "ankit";

// let reverse1 = value11.toString().split("").reverse().join("");
// console.log(reverse1);
// // by loop

// let strr = "tikna";
// let rever = "";
// for (i = strr.length - 1; i >= 0; i--) {
//   rever += strr[i];
// }
// console.log(rever);

// // swap number
// // let g = 2;
// // let h = 4;
// // let tp;

// // tp = g;
// // g = h;
// // h = tp;
// // console.log(g);
// // console.log(h);

// // without third variable

// let g = 2;
// let h = 4;

// g = h + g; //6
// h = g - h; // 2
// g = g - h;

// console.log(g);
// console.log(h);

// let strAry = [
//   { id: 1, name: "ankit", population: 4 },
//   { id: 2, name: "abhi", population: 4 },
//   { id: 3, name: "dk", population: 4 },
//   { id: 4, name: "narayan", population: 4 },
// ];

// //map
// let results = strAry.map((item) => {
//   return { id: item.id, name: item.name };
// });
// console.log(results);
// let result1 = strAry.map((elem) => {
//   return elem.id;
// });
// console.log(result1);

// //reduce
// let result2 = strAry.reduce((acc, item) => {
//   return acc + item.population;
// }, 0);
// console.log(result2);

// // empty an array

// let arr2 = [1, 3, 4, 4, 4, 9];

// // arr2 = []; //1st
// // arr2.length = 0; //2nd
// // arr2.splice(0, arr2.length); //3rd
// while (arr2.length) {
//   arr2.pop();
// } //4th
// console.log(arr2);

// // check if number is integer

// // find largest number
// // parseFloat
// let num1 = 23;
// let num2 = 18;
// let num3 = 25;

// let largest = Math.max(num1, num2, num3);
// console.log(largest);

// // carrying

// function add(num1) {
//   return function (num2) {
//     console.log(num1 + num2);
//   };
// }
// add(2)(3);

// // armstrong number

// let x = 153;
// let com = 0;
// let tem = x;
// while (tem > 0) {
//   y = tem % 10;
//   com += y ** 3;
//   tem = parseInt(tem / 10);
// }
// console.log(x, com);

// if (x == com) {
//   console.log("armstrong");
// } else {
//   console.log("not armstrong");
// }

// print star
// for (let i = 1; i < 5; i++) {
//   for (let j = 1; i <= i; j++) {
//     console.log("*");
//   }
//   console.log("\n");
// }
// for (var i = 1; i <= 4; i++) {
//   console.log("*".repeat(i));
// }
// let n = 5;
// let string = "";
// // External loop
// for (let i = 1; i <= n; i++) {
//   // printing spaces
//   for (let j = 1; j <= n - i; j++) {
//     string += " ";
//   }
//   // printing star
//   for (let k = 0; k < 2 * i - 1; k++) {
//     string += "*";
//   }
//   string += "\n";
// }
// console.log(string);

// let deletes = ["q", "b", "c"];

// let del = deletes.splice(0, deletes.length);
// console.log(del);

// Infinite Currying in JavaScript >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// const add = (a) => {
//   return (b) => {
//     if (b) return add(a + b);
//     return a;
//   };
// };
// console.log(add(2)(2)(2)(2)());


// let promise = new Promise(() => {
//   console.log("hii Promise");
// });
// console.log("hii another");

// setTimeout(() => {
//   console.log("hello  setTimeout");
// }, 2000);

// const array = [1, "a", 2, "sd", 3, "c", "d"];

// let num = [];
// let str = [];
// for (let i = 0; i < array.length; i++) {
//   if (typeof array[i] === "number") {
//     num.push(array[i]);
//   }
//   if (typeof array[i] === "string") {
//     str.push(array[i]);
//   }
// }
// console.log(str);
// console.log(num);
// array.forEach((element) => {
//   if (typeof element === "number") {
//     num.push(element);
//   }
//   if (typeof element === "string") {
//     str.push(element);
//   }
//   console.log(element);
// });

// const target = { a: 1, b: 2 };
// const source = { b: 4, c: 5 };

// const returnedTarget = Object.assign(target, source);

// console.log(target);
// console.log(returnedTarget === target);

// const obj = { name: "Ben" };
// obj.age = 22;
// console.log(obj);

//print 1 to 9 after one one sec
// for (let i = 0; i < 10; i++) {
//   setTimeout(() => {
//     console.log(i);
//   }, 1000 * i);
// }


/////////////// find the common key value in both object /////////////////////
// const input1 = { a: 1, b: 2, c: 3, d: 8, e: 10 };
// const input2 = { a: 2, e: 10, f: 7, d: 8 };

// const fun = (input1, input2) => {
//   let output = {};
//   for (let i in input1) {
//     if (input1[i] == input2[i]) {
//       output[i] = input1[i];
//     }
//   }
//   return output;
// };
// console.log(fun(input1, input2));

/////////////////// Creating a simple Promise ////////////////////////////////////

// const myPromise = new Promise((resolve, reject) => {
//     setTimeout(() => {
//       const randomNumber = Math.random();
//       if (randomNumber > 0.5) {
//         resolve(`Success: ${randomNumber}`);
//       } else {
//         reject(`Error: ${randomNumber}`);
//       }
//     }, 1000);
//   });
//     myPromise
//     .then((result) => {
//       console.log(result);
//     })
//     .catch((error) => {
//       console.error(error);
//     });


/////////////// DOM manipulation //////////////////////////
// refer to index.html


////  1)  selector
// var a=document.querySelector("h1")
// console.log(a)

//// 2) changing html
// a.innerHTML="h1 is changed"

//// 3) changing css
// a.style.color="gray"
// a.style.backgroundColor="blue"

//// 4) adding event listner
// a.addEventListener("click",()=>{
//   a.innerHTML="i am changed"
//   a.style.color="blue"
//   a.style.border="1px solid black"
//   a.style.borderRadius="10px"
//   a.style.backgroundColor="yellow"
// })
let a=document.querySelector(".bulb")
let b=document.querySelector("button")
let bulb=0
b.addEventListener("click",()=>{
  if(bulb==0){
    a.style.backgroundColor="yellow"
    b.innerHTML="Off"
    bulb=1
  }else{
    a.style.backgroundColor="gray"
    bulb=0
    b.innerHTML="On"
  }
})

let head=document.querySelector(".headings")
let fheadid=document.querySelector("#f")
let sheadId=document.querySelector("#s")
let theadId=document.querySelector("#t")

head.addEventListener("click",(e)=>{
  if(e.target.tagName==="H3"){
    head.style.backgroundColor="green"
    alert(` you click on heading name ${e.target.innerText}`)
  }
})
///////////////////// find factorials ///////////

// const promp=prompt("enter the number")

// let num=1
// if(num<0){
//   alert("enter valid number")
// }else{
//   for(let i=num;i<promp;i++){
//     num+=num*i
//   }
// }
// console.log(num)

///////// shallow copy and dip copy ///////////////////////////////////////////
/// shallow copy
// let abc={
//   id:1,
//   name:"aniruddh"
// }

// let def=abc

// def.id=2
// def.id=3
// console.log(def)

//Dip copy
// def="xyz"
// console.log(def)


//////////////   spread operator////////////////////////////////////////////

// let array=[1,2,3,4,]
// let newArray=[...array,5]
// console.log(newArray);
// console.log(array)


// let object={
//   id:1
// }

// let newObject={
//   ...object,
//   name:"aniruddh"
// }

// console.log(object)
// console.log(newObject)


////////////////// callback functions /////////////////////////////////

// let object=[
//   {name:"aniruddh"},
//   {name:"dahate"},
// ]

// const funA=()=>{
//   setTimeout(()=>{
//     object.forEach((element)=>{
//       console.log(`my name is ${element.name}`)
      
//     })
//   },1000)
// }
// const fun2=(newData,callback)=>{
//   setTimeout(()=>{
//     object.push(newData)
//     console.log(object)
//     callback()
//   },2000)

  
// }

// fun2({name:"ghanshyam"},funA)



/////////////////////////////////// this code is danger////////////////////////////

// let startDate = new Date().getTime()
// let end =startDate
// while(end < startDate +10000){
//  // end = startDate.getTime()
//  console.log("end date")
// }

/////////////////////////////////above code is danger ////////////////////////////
// const data = {
//   name:"Niles"
// }

// Object.assign(data,{id:20})

// console.log(data)


// const array=[2,4,6,8,10]

// const fun =function area(a){
//   return Math.PI *a*a
// }

// console.log(fun(array))

// const fun3=function diameter (a){
//   return 2*a
// }


//  Array.prototype.calculate =function(logic) {
//   let areaCircle =[]
//   for(let i=0;i<this.length;i++){
//     // areaCircle=Math.PI*r*r  
//     areaCircle.push(logic(this[i]))
//   }
//   return areaCircle
// }

// console.log(array.calculate(fun3))

// console.log(calculate(fun3,array))
// console.log(calculate(fun,array))

// function dia(a) {
  
//   let areaCircle =[]
//   for(let r=0;r<a.length;r++){
//     // areaCircle=Math.PI*r*r  
//     areaCircle.push( a[r]*a[r])
//   }
//   return areaCircle
// }


// console.log(dia(array))
// console.log(calculate(array))
// const area =function(r){
//   return Math.PI*r*r
// }

// const diameter = function(d){
//   return 2*d
// }

// console.log(array.map(area))
// console.log(array.map(diameter))


/////////////////// task table of 2 to 5////////////////////////// 
  // for(let i=2;i<6;i++){
  //   console.log("table of ", i)
  //   for(let j=1;j<=10;j++){
  //     console.table( i*j)
  //   }
  // }

  ////////////////////// print a10 - z26 //////////////////////////////////////
//   const options = [];
// for (let i = 10; i < 36; i++) {
//   options.push({
//     value: i.toString(36) + i,
//     // label: i.toString(36) + i,
//   });
// }
// console.log(options)

// let array=[1,2,8,3,9,4,5,6]
////////// find second largest value
// const fun=(para)=>{
//   let abc=para.sort((a, b)=>b-a)
//   return abc[1]
// }
// console.log(fun(array))


////////////// calsulate the total salery of a, b, c ////////////////////
const emp = [
  { name: 'a', sal: 200 },
  { name: 'b', sal: 200 },
  { name: 'a', sal: 500 },
  { name: 'b', sal: 200 },
  { name: 'c', sal: 300 }
];
function calculateTotalSalary(employees) {
  const result = {};
  employees.forEach(employee => {
    const { name, sal } = employee;
    if (result[name]) {
      result[name] += sal;
    } else {
      result[name] = sal;
    }
  });
  return result;
}
const totalSalaryByEmployee = calculateTotalSalary(emp);
console.log(totalSalaryByEmployee);

/////////// want output like , output = [ 14,13,12,11,10] => Means at every index addition of another elements except that index element 
const input = [1, 2, 3, 4, 5];

const output=input.map((element,index)=>{
  let sum=input.reduce((acc,curr,i)=>(i !==index ? acc + curr : acc),0)
  return sum
})

console.log(output)