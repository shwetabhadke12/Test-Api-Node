//-------------------------- (1) for Loop ---------------------------

// (1) basic for loop
// for (let i = 0; i < 10; i++) {
//   console.log(i);
// }

// (2) find total
// let total = 0;
// for (let i = 0; i < array.length; i++) {
//   total = total + array[i];
// }
// console.log(total);

//(3) find average
// const arr = [10, 20, 30, 40, 50, 60];
// let sum = 0;
// for (let i = 0; i < arr.length; i++) {
//   sum = sum + arr[i];
// }
// sum = sum / arr.length;
// console.log(sum);

// (4) find duplicate numvbers
// let arr1 = [1, 2, 3, 4, 5, 6, 3, 4, "abc", "bcd", "abc"];
// let arrDup = [];
// for (let i = 0; i < arr1.length; i++) {
//   if (!arrDup.includes(arr1[i])) {
//     arrDup.push(arr1[i]);
//   }

// }
// console.log(arrDup);

// const d=arr1.filter((x, y)=> arr1.indexOf(x) == y)
// console.log(d, "mioo")
// (5)  duplicate elements array
// let arr2 = [1, 2, 3, 4, 5, 6, 3, 4, "abc", "bcd", "abc"];

//   let dupArr = arr2.filter((item, index) => arr2.indexOf(item) == index);
//   console.log(dupArr);


//-------------------------  (2) for in Loop  -----------------------------

// var student = {
//   name: "David Rayy",
//   class: "VI",
//   rollno: 12,
//   marks: 70,
// };
// for (let i in student) {
//   console.log(i);
// }

//-----------------------------  (3) for(of) Loop  ----------------------------

// var student = {
//   name: "David Rayy",
//   class: "VI",
//   rollno: 12,
//   marks: 70,
// };
// for (let i of "student") {
//   console.log(i);
// }

// let arr1 = [1, 2, 3, 4, 5, 6, 3, 4];
// let forLoop;
// for (let i of arr1) {
//   console.log(i);
// }

// for (var i = 1; i <= 10; i++) {
//   console.log("  * ".repeat(i));
// }
// let n = 5;
// let string = "";
// for (let i = 1; i <= n; i++) {
//   for (let j = 1; j <= n - i; j++) {
//     string += " ";
//   }
//   for (let k = 0; k < 2 * i - 1; k++) {
//     string += "*";
//   }
//   string += "\n";
// }
// console.log(string)


